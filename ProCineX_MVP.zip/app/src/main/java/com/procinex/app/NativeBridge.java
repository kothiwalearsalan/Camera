package com.procinex.app;
public class NativeBridge {
    static { System.loadLibrary("procinex_core"); }
    public static native String stringFromJNI();
}
