# ProCineX — Minimal Android Studio Project (MVP scaffold)

This scaffold builds a debug APK with CameraX basic capture stubs and native processing stubs.
It is ready to upload to GitHub and used with the included GitHub Actions workflow to produce `app-debug.apk`.

## How to get an installable APK from mobile (quick)
1. Download this ZIP on your phone.
2. Upload the ZIP to a new GitHub repository (via GitHub mobile website or app) and push to `main`.
3. On the repository page open the **Actions** tab — the workflow `Android Debug Build` will run automatically.
4. When finished, open the workflow run and download the artifact named `app-debug-apk`.
5. Sideload the APK on your Android device.

> Note: The debug APK is unsigned for release and uses a debug keystore. Do not use it in production.

